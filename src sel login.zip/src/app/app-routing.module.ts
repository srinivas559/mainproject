import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DeleteitemComponent} from './deleteitem/deleteitem.component';
import {AdditemComponent} from './additem/additem.component';
import { UpdatestockComponent } from './updatestock/updatestock.component';
import { SellerloginComponent } from './sellerlogin/sellerlogin.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';


const routes: Routes = [
  {path:'additem',component:AdditemComponent},
  {path:'deleteitem',component:DeleteitemComponent},
  {path:'updatestock',component:UpdatestockComponent},
  {path:'sellerlogin',component:SellerloginComponent},
  {path:'sellersignup',component:SellersignupComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
