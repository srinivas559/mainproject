import { Component, OnInit } from '@angular/core';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-deleteitem',
  templateUrl: './deleteitem.component.html',
  styleUrls: ['./deleteitem.component.css']
})
export class DeleteitemComponent implements OnInit {
  
  
  productid:number;

  ngOnInit(): void {
    this.productid=0;
  }
  constructor(private del:SellerServiceService) { }
  onSubmit()
  {
    this.del.deleteItems(this.productid).subscribe();
  }
}
