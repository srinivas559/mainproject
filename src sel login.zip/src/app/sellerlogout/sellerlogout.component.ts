import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellerlogout',
  templateUrl: './sellerlogout.component.html',
  styleUrls: ['./sellerlogout.component.css']
})
export class SellerlogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
