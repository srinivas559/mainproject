import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { UpdatestockComponent } from './updatestock/updatestock.component';
import { AdditemComponent } from './additem/additem.component';
import { DeleteitemComponent } from './deleteitem/deleteitem.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { SellerloginComponent } from './sellerlogin/sellerlogin.component';
import { HomeComponent } from './home/home.component';
import { SellerlogoutComponent } from './sellerlogout/sellerlogout.component';

@NgModule({
  declarations: [
    AppComponent,
    UpdatestockComponent,
    AdditemComponent,
    DeleteitemComponent,
    SellersignupComponent,
    SellerloginComponent,
    HomeComponent,
    SellerlogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
