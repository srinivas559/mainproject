package com.example.demo.services;

import org.springframework.stereotype.Service;

import com.example.demo.Entity.SellerDetails;
@Service
public interface ISellerService {

	String addSeller(SellerDetails sdetails);

	String updateSeller(Integer sellerid, SellerDetails sdetails);

}
