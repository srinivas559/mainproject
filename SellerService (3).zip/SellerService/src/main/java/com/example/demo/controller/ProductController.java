package com.example.demo.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Product;
import com.example.demo.services.IProductService;

@RestController

@CrossOrigin(origins = "*")
@RequestMapping("/product")
public class ProductController
{
	@Autowired
	public IProductService iprodserv;
	
	
	@GetMapping("/getAllProduct")
	public List<Product> getAllProducts()
	{
		return iprodserv.getAllProducts();
	}
	
	
	@PostMapping("/addProduct/{subcategoryid}/{sellerid}")
	public String addProduct(@PathVariable("subcategoryid") int subcatid,@PathVariable("sellerid") int sellerid,@RequestBody Product prodetails)
	{
		return iprodserv.addProduct(subcatid,sellerid,prodetails);
	}
	
@DeleteMapping("/DeleteItem/{sellerid}/{productid}")
public String deleteProduct(@PathVariable("productid") int prodid,@PathVariable("sellerid") int sellerid)
{iprodserv.deleteProduct( prodid,sellerid);
	return "Product Deleted";
}

@PostMapping("/updateProduct/{seleerid}/{productid}")
public String updateProduct(@RequestBody Product pdetails,@PathVariable("seleerid") int sellerid,@PathVariable("productid") int prodid)
{   
	iprodserv.updateProduct( pdetails,sellerid,prodid);
	return "Product Updated";
}


	
	  @GetMapping("/getMatchItems/{proname}") 
	  public List<Product> searchProduct(@PathVariable("proname") String productname){ 
		  return iprodserv.searchProduct(productname); }
	 
}
