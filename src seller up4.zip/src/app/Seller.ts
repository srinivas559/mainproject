export class Seller
{
    
	username:String;
	password:String;
    companyname:String;
	Gstin:number;
	companydescription:String;
	postal_address:String;
	website:String;
	emailid:String;
	contact_number:number;
}