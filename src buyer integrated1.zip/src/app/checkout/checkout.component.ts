import { Component, OnInit } from '@angular/core';
import { ShopCart } from '../Shoppingcart';
import { Transaction } from '../transactions';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  
  tran:Transaction=new Transaction();
  scart:ShopCart=new ShopCart();
 


  constructor(private displaycart:BuyerServiceService) { }

  ngOnInit(): void {
  }
  
  checkOut(checkout:ShopCart)
  {
   this.displaycart.checkOutCart(checkout).subscribe( tran => this.tran=tran);
    console.log("in checkout");
  }

}
