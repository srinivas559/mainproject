import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {ShopCart } from './Shoppingcart';
import { User } from './Buyer';
import { ApiResponse } from './api.response';

@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  

  private baseUrl="http://localhost:8082/product";
  private baseUrl1="http://localhost:8081/cart/addItem/2";
  private baseUrl2="http://localhost:8081/buyer";
  private baseUrl3="http://localhost:8081/cart";
  constructor(private http:HttpClient ) { }
  getItemsByName(productName: String) :Observable<any> {
    return this.http.get(`${this.baseUrl}`+`/getMatchItems`+`/${productName}`);
  }

  addCart(cart:object):Observable<any> {
    console.log("ejfhw");
    console.log(cart);
   return  this.http.post(`${this.baseUrl1}`,cart);
  }

  createbuyer(buyer: User) :Observable<any>{
    console.log("in service");
    return this.http.post(`${this.baseUrl2}`+`/addUser`,buyer);
   } 
  
  displayCartItems() : Observable<any>{

    return this.http.get(`http://localhost:8081/cart/getItems`);
 
  }
  deleteCartItem() :Observable<any>{
    return this.http.delete(`http://localhost:8081/cart/deleteItem/4`);
  }
  
  emptyCart() :Observable<any>{
    return this.http.delete(`http://localhost:8081/cart/emptyCart/2`);
  }


  updateCartItems(incart: ShopCart) :Observable<any>{
    console.log("jfshjsg");
    console.log(incart);
   return this.http.post(`http://localhost:8081/cart/updatecart/4`,incart);
  }

  checkOutCart(checkout:ShopCart) :Observable<any>
  {
   
    return this.http.post(`http://localhost:8081/cart/checkout/2`,checkout);
    
 
  }

  getCartItems() :Observable<any>
  {
    return this.http.get(`${this.baseUrl}`+`/getAllProduct`);
  }

  getPurchaseHistory()  :Observable<any>
  {
    return this.http.get(`${this.baseUrl3}`+`/purchasehistory`);
  }

  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8081/' + 'token/generate-token', loginPayload);
  }
  
}