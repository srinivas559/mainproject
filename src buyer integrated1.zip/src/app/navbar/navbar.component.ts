import { Component, OnInit } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { Product } from '../Items';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  productname:String;
  product: Product[];
  constructor(private dataService:BuyerServiceService,private router:Router) { }


  ngOnInit(): void {
  }

  private searchProducts() {
    this.dataService.getItemsByName(this.productname)
    .subscribe(product => this.product = product);
    this.router.navigate(['Home']);
  }

  onSubmit() {
    console.log("in sumbit");
    this.searchProducts();
  }
}
