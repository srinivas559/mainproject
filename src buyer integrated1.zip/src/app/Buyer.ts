export class User
{
    buyerid: number;
    emailid:String;
    mobile_number:number;
    password:String;
    username:String;
}
    