import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddcartComponent } from './addcart/addcart.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { UpdatecartComponent } from './updatecart/updatecart.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import { HomeComponent } from './home/home.component';
import { BuyerlogoutComponent } from './buyerlogout/buyerlogout.component';
import { NavbarComponent } from './navbar/navbar.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { PurchasehistoryComponent } from './purchasehistory/purchasehistory.component';
import { BuyerServiceService } from './buyer-service.service';
import { TokenInterceptor } from './interceptor';



@NgModule({
  declarations: [
    AppComponent,
    AddcartComponent,
    DisplaycartComponent,
    UpdatecartComponent,
    BuyersignupComponent,
    BuyerloginComponent,
    HomeComponent,
    BuyerlogoutComponent,
    NavbarComponent,
    CheckoutComponent,
    PurchasehistoryComponent,

   
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
    
  ],
  providers: [BuyerServiceService, {provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
