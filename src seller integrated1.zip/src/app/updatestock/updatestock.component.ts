import { Component, OnInit } from '@angular/core';
import { SellerServiceService } from '../seller-service.service';
import { Product } from '../Items';

@Component({
  selector: 'app-updatestock',
  templateUrl: './updatestock.component.html',
  styleUrls: ['./updatestock.component.css']
})
export class UpdatestockComponent implements OnInit {
  product:Product=new Product();

  constructor(private up:SellerServiceService) { }

  ngOnInit(): void {
  }

  onSubmit()
  {
    this.up.updateStock(this.product).subscribe(product => this.product = product);
  }

}
