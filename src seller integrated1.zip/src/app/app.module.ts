import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdditemComponent } from './additem/additem.component';
import { DeleteitemComponent } from './deleteitem/deleteitem.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { SellerloginComponent } from './sellerlogin/sellerlogin.component';
import { HomeComponent } from './home/home.component';
import { SellerlogoutComponent } from './sellerlogout/sellerlogout.component';
import { UpdateitemComponent } from './updateitem/updateitem.component';
import { SellerServiceService } from './seller-service.service';
import { TokenInterceptor } from './interceptor';
import { UpdatestockComponent } from './updatestock/updatestock.component';

@NgModule({
  declarations: [
    AppComponent,
    UpdateitemComponent,
    AdditemComponent,
    DeleteitemComponent,
    SellersignupComponent,
    SellerloginComponent,
    HomeComponent,
    SellerlogoutComponent,
    UpdatestockComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [SellerServiceService, {provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
