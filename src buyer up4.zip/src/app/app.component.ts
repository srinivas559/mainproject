import { Component } from '@angular/core';
import { Product } from './Items';
import { BuyerServiceService } from './buyer-service.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  productname:String;
  product: Product[];
  title = 'my-app8';
  constructor(private dataService:BuyerServiceService) { }
  private searchProducts() {
    this.dataService.getItemsByName(this.productname)
    .subscribe(product => this.product = product);
  }

  onSubmit() {
    this.searchProducts();
  }
}
