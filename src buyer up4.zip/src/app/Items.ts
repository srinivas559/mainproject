export class Product
{
    productid:number;
     productname: String;
	 Manufacturer: String;
     Model:String;
		
	 sdetails:number;
		 price:number;
		quantity:number;
		decription:String;
}