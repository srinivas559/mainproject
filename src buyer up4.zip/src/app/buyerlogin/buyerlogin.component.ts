import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../Buyer';

@Component({
  selector: 'app-buyerlogin',
  templateUrl: './buyerlogin.component.html',
  styleUrls: ['./buyerlogin.component.css']
})
export class BuyerloginComponent implements OnInit {

  

  ngOnInit(): void {
  }
  username:string;
  password:string;
   user:User=new User();
  constructor( private router: Router) { }

  onSubmit() {
    console.log(this.user.username);
    console.log(this.user.password);
   
      if(this.user.username=="vicky559" && this.user.password=="vicky559")
      {
        this.router.navigate(['Home']);
        alert("login successful");
      }
      else
      {
        alert("Enter the correct username and password");
      }
    }
}
