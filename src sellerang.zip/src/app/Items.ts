export class Product
{
    productid:number;
	productname:String
    manufacturer:String
    model:String
	sdetails:number;
    price:number;
	quantity:number;
	scatogery:number;
	decription:String;
}