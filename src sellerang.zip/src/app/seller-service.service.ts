import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Product } from './Items';


@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  
  private baseUrl="http://localhost:8082/product"
  constructor(private http : HttpClient) {}
  addItems(product: Product)  :Observable<any>{
    return this.http.post(`${this.baseUrl}/addProduct/1/1`,product);
   }
   deleteItems(productid: number) :Observable<any>{
     return this.http.delete(`${this.baseUrl}/DeleteItem/{productid}/1`,{responseType:'text'});
   }
   updateItems(productid: number):Observable<any>{
    return this.http.post(`${this.baseUrl}/updateProduct/${productid}/1`,{responseType:'text'});
   }
     
   
}
