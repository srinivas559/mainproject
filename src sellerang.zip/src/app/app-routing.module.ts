import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DeleteitemComponent} from './deleteitem/deleteitem.component';
import {AdditemComponent} from './additem/additem.component';
import { UpdatestockComponent } from './updatestock/updatestock.component';


const routes: Routes = [
  {path:'additem',component:AdditemComponent},
  {path:'deleteitem',component:DeleteitemComponent},
  {path:'updatestock',component:UpdatestockComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
