package com.example.demo.Entity;

public class AuthToken {

    private String token;
    private String username;
    private int sellerid;

    public AuthToken(){

    }

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getSellerid() {
		return sellerid;
	}

	public void setSellerid(int sellerid) {
		this.sellerid = sellerid;
	}

	public AuthToken(String token, String username, int sellerid) {
		super();
		this.token = token;
		this.username = username;
		this.sellerid = sellerid;
	}
}
   