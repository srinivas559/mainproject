package com.example.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.Entity.SellerDetails;

@Service
public interface ISellerService {

	SellerDetails addSeller(SellerDetails sdetails);

	String updateSeller(Integer sellerid, SellerDetails sdetails);
	
	

	List<SellerDetails> getSellers();

}
