package com.example.demo.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productid;
	    private String productname;
		private String Manufacturer;
		private String Model;
		private String Category;
		//sellerId: 23
		
		@ManyToOne
		@JoinColumn(name="sellerid")
		@OnDelete(action = OnDeleteAction.CASCADE)
		private SellerDetails sdetails;
		
		private float Price;
		private int Quantity;
		
		
		


		@ManyToOne
		@JoinColumn(name="category_id")
		@OnDelete(action = OnDeleteAction.CASCADE)
		private SubCategory scategory;
		
		private String decription;
		//picture: 
		public int getProductid() {
			return productid;
		}
		public void setProductid(int productid) {
			this.productid = productid;
		}
		public String getProductname() {
			return productname;
		}
		public void setProductname(String productname) {
			this.productname = productname;
		}
		public String getManufacturer() {
			return Manufacturer;
		}
		public void setManufacturer(String manufacturer) {
			Manufacturer = manufacturer;
		}
		public String getModel() {
			return Model;
		}
		public void setModel(String model) {
			Model = model;
		}
		public SellerDetails getSdetails() {
			return sdetails;
		}
		public void setSdetails(SellerDetails sdetails) {
			this.sdetails = sdetails;
		}
		public float getPrice() {
			return Price;
		}
		public void setPrice(float price) {
			Price = price;
		}
		public int getQuantity() {
			return Quantity;
		}
		public void setQuantity(int quantity) {
			Quantity = quantity;
		}
		public SubCategory getScategory() {
			return scategory;
		}
		public void setScategory(SubCategory scategory) {
			this.scategory = scategory;
		}
		public String getDecription() {
			return decription;
		}
		public void setDecription(String decription) {
			this.decription = decription;
		}
		
		public Product() {
			System.out.println("Product Details Object Has been Created");
			
		}
		public String getCategory() {
			return Category;
		}
		public void setCategory(String category) {
			Category = category;
		}
		public Product(int productid, String productname, String manufacturer, String model, String category,
				SellerDetails sdetails, float price, int quantity, SubCategory scategory, String decription) {
			super();
			this.productid = productid;
			this.productname = productname;
			Manufacturer = manufacturer;
			Model = model;
			Category = category;
			this.sdetails = sdetails;
			Price = price;
			Quantity = quantity;
			this.scategory = scategory;
			this.decription = decription;
		}
		@Override
		public String toString() {
			return "Product [productid=" + productid + ", productname=" + productname + ", Manufacturer=" + Manufacturer
					+ ", Model=" + Model + ", Category=" + Category + ", sdetails=" + sdetails + ", Price=" + Price
					+ ", Quantity=" + Quantity + ", scategory=" + scategory + ", decription=" + decription + "]";
		}
		
		
		
		
	
}
