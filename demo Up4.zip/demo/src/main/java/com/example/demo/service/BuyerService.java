package com.example.demo.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BuyerDao1;
import com.example.demo.dao.UserDao;
import com.example.demo.entity.Buyer;
import com.example.demo.entity.Product;

@Service
public class BuyerService implements IBuyerService,UserDetailsService{
	
	
	

	@Autowired
	public BuyerDao1 dao;
	@Autowired
	public UserDao udao;
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	public List<Product> getAllProducts()
	{
		
		return  dao.findAll();
	}
	public Buyer addProduct(Buyer buyer) {
		
		 buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
			return udao.save(buyer);
	}

	public List<Buyer> getUsers() {
		
		return udao.findAll();
	}
	public String findByIdAndPostId(int buyerid) {
		udao.deleteById(buyerid);
		return "/User Deleted/";
	}
	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Buyer user = udao.findByUsername(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
	
	public Buyer findOne(String username) {
		// TODO Auto-generated method stub
		return udao.findBuyerByUsername(username);
	}
	

}

