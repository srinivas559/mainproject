package com.example.demo.entity;

public class AuthToken {

	private int buyerid;
    private String token;
    private String username;

    public AuthToken(){
    	
    }

	public int getBuyerid() {
		return buyerid;
	}

	public void setBuyerid(int buyerid) {
		this.buyerid = buyerid;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public AuthToken(String token, String username,int buyerid) {
		super();
		this.buyerid = buyerid;
		this.token = token;
		this.username = username;
	}

   


}