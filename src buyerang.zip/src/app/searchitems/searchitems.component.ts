import { Component, OnInit } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { Product } from '../Items';

@Component({
  selector: 'app-searchitems',
  templateUrl: './searchitems.component.html',
  styleUrls: ['./searchitems.component.css']
})
export class SearchitemsComponent implements OnInit {

  productname:String;
  product: Product[];
  title = 'BuyerPart';

  constructor(private dataService:BuyerServiceService) { }
  ngOnInit(){
    this.productname="";
  } 
    private searchProducts() {
      this.dataService.getItemsByName(this.productname)
      .subscribe(product => this.product = product);
    }
  
    onSubmit() {
      this.searchProducts();
    }
}
