import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {SearchitemsComponent} from './searchitems/searchitems.component';
import {DisplaycartComponent} from './displaycart/displaycart.component';
import {BuyersignupComponent} from './buyersignup/buyersignup.component';
const routes: Routes = [ 
  {path : 'buyersignup',component:BuyersignupComponent},
  {path : 'searchitems',component:SearchitemsComponent},
  {path : 'displaycart' , component:DisplaycartComponent},
  {path: 'buyer-signup', component: BuyersignupComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
