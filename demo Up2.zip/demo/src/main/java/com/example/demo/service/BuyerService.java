package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BuyerDao1;
import com.example.demo.dao.UserDao;
import com.example.demo.entity.Buyer;
import com.example.demo.entity.Product;

@Service
public class BuyerService implements IBuyerService{
	
	
	

	@Autowired
	public BuyerDao1 dao;
	@Autowired
	public UserDao udao;
	
	public List<Product> getAllProducts()
	{
		
		return  dao.findAll();
	}
	public String addProduct(Buyer buyer) {
		
		 udao.save( buyer);
		return "/User Added/";
	}

	public List<Buyer> getUsers() {
		
		return udao.findAll();
	}
	public String findByIdAndPostId(int buyerid) {
		udao.deleteById(buyerid);
		return "/User Deleted/";
	}
	

}

