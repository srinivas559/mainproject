package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.dao.BuyerDao1;
import com.example.demo.dao.CartDao;
import com.example.demo.dao.PurchaseHistoryDao;
import com.example.demo.dao.TransactionDao;
import com.example.demo.dao.UserDao;
import com.example.demo.entity.Buyer;
import com.example.demo.entity.PurchaseHistory;
import com.example.demo.entity.ShoppingCart;
import com.example.demo.entity.Transactions;

@Service
public class CartService implements ICartService {
	
	@Autowired
	public CartDao cdao;
	@Autowired
	public UserDao udao;
	@Autowired
	public BuyerDao1 bdao;
	@Autowired
	public TransactionDao tdao;
	@Autowired
	public PurchaseHistoryDao pdao;
	
	public String addCartItem(int buyerid,ShoppingCart cart)
	{
		Buyer br=udao.getOne(buyerid);
		cart.setUser(br);
		System.out.println("cart");
		System.out.println(cart);
		cdao.save(cart);
		
		return "\"Item added\"";
	}
	public List<ShoppingCart> getCart()
	{
		System.out.println("In CartService");
		return cdao.findAll();
	}
	
	public String deleteCartItem(int cart_id)
	{
		cdao.deleteById(cart_id);
		return "\" Item Deleted from te cart\"";
	}

    public void emptyCart(int buyid)
    {
    	cdao.emptyCart(buyid);
    	
    }
    
    public String updateCart( ShoppingCart scart1,int buid) 
	{
		Buyer br1=udao.getOne(buid);
		System.out.println("hii"+scart1); 
		ShoppingCart sr=cdao.getOne(scart1.getCart_Id());
		
		int prid=scart1.getProductid();
		int quantity=scart1.getQuantity();
		float tprice=scart1.getTotal_price();
		
		sr.setProductid(prid);
		sr.setQuantity(quantity);
		sr.setTotal_price(tprice);
		sr.setUser(br1);
		System.out.println(sr);
		cdao.save(sr);
		return "\"Cart item updated\"";
	}
	
    @Override
	public String checkOut(Transactions tran, int buyerid) {
		Buyer buyer=udao.getOne(buyerid);
		System.out.println(buyer);
		tran.setUser(buyer);
		
		
		
		float sum=0;
		List<ShoppingCart> shcart1=cdao.byid(buyerid);
		for(int i=0;i<shcart1.size();i++)
		{
			PurchaseHistory phis=new PurchaseHistory();
			ShoppingCart shcartitems=shcart1.get(i);
			int size=shcartitems.getQuantity();
			float cost=shcartitems.getTotal_price();
			phis.setPrice(cost);
			phis.setNumber_of_items(size);
			phis.setUser(buyer);
			sum=sum+cost;
			System.out.println(phis);
			
      		cdao.deleteById(shcartitems.getCart_Id());
			pdao.save(phis);
			
			
		}
		tran.setTotalcost(sum);
		System.out.println(tran);
		tdao.save(tran);	
		return "Transaction complited succeccfully";
	}
	  
	 
}


